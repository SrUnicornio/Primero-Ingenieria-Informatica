/**
 * @file Racionales_main.cpp
 * @author Alvaro Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 27 2022
 * @brief Desarrollo de la clase Racionales_main
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos
*/

#include "Racionales.h"

int main() {
  Racionales racional1(1, 2);
  Racionales racional2(1, 3);
  Racionales racional3(0, 0);
  racional3.Suma(racional1, racional2);
  racional3.Resta(racional1, racional2);
  racional3.Multiplicacion(racional1, racional2);
  racional3.Division(racional1, racional2);
  return 0;
}