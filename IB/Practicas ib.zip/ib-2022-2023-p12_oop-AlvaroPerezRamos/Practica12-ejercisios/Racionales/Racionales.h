/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file Racionales.h
 * @author Alvao Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 4 2022
 * @brief Desarrollo de la clase Racionales
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos
 */

#ifndef Racionales_h
#define Racionales_h

#include <iostream>
#include <cmath>
#include <fstream>
#include <string>

using namespace std;

class Racionales {
public:
    //entrada es un fichero de texto
    Racionales(int numerador, int denominador);
    void Suma(Racionales racional1, Racionales racional2);
    void Resta(Racionales racional1, Racionales racional2);
    void Multiplicacion(Racionales racional1, Racionales racional2);
    void Division(Racionales racional1, Racionales racional2);

private:
    int numerador_;
    int denominador_;
};

#endif