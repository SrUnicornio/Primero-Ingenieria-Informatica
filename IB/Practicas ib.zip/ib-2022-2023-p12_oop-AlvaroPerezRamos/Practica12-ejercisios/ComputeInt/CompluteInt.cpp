/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file ComputeInt.cpp
 * @author Alvaro Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 27 2022
 * @brief Desarrollo de la clase ComputeInt
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos
 */

#include "ComputeInt.h"

/**
 *@brief Constructor por defecto
 *@param kNumero
 *@param kNumero2
 */
ComputeInt::ComputeInt() {
  kNumero = 0;
  kNumero2 = 0;
}

/**
 *@brief Constructor con parametros
 *@param kNumero
 *@param kNumero2
 */
ComputeInt::ComputeInt(int kNumero, int kNumero2) {
  this->kNumero = kNumero;
  this->kNumero2 = kNumero2;
}

/**
 *@brief Calcula el factorial de un numero
 *@param kNumero
 */

void ComputeInt::Factorial(int kNumero) {
  int factorial = 1;
  for (int i = 1; i <= kNumero; i++) {
    factorial *= i;
  }
  cout << "El factorial de " << kNumero << " es: " << factorial << endl;
}

/**
 *@brief Calcula la suma de una serie
 *@param kNumero
 */
void ComputeInt::SumSerie(int kNumero) {
  int suma = 0;
  for (int i = 1; i <= kNumero; i++) {
    suma += i;
  }
  cout << "La suma de la serie es: " << suma << endl;
}

/**
 *@brief Calcula si un numero es primo
 *@param kNumero
 *@return true si es primo, false si no lo es
 */
bool ComputeInt::IsPrime(int kNumero) {
  for (int i = 2; i*i <= kNumero; i++) {
    if (kNumero % i == 0) {
      return false;
    }
  }
  if (kNumero == 1 || kNumero == 0) {
    return false;
  }
    return true;
}

/**
 *@brief Calcula si un numero es primo perfecto
 *@param kNumero
 */
void ComputeInt::IsPerfectPrime(int kNumero) {
    int suma = 0;
    int aux = kNumero;
    do {
      suma += aux % 10;
      aux /= 10;
    } while (aux > 0);
    if (IsPrime(kNumero) == true && IsPrime(suma) == true) {
        cout << "El numero " << kNumero << " es primo perfecto" << endl;
    } else {
        cout << "El numero " << kNumero << " no es primo perfecto" << endl;
    }
}

/**
 *@brief Calcula si dos numeros son primos relativos
 *@param kNumero
 *@param kNumero2
 */
void ComputeInt::AreRelativePrime(int kNumero, int kNumero2) {
    int aux = kNumero;
    int aux2 = kNumero2;
    int resto = 0;
    do {
        resto = aux % aux2;
        aux = aux2;
        aux2 = resto;
    } while (resto != 0);
    if (aux == 1) {
        cout << "Los numeros " << kNumero << " y " << kNumero2 << " son primos relativos" << endl;
    } else {
        cout << "Los numeros " << kNumero << " y " << kNumero2 << " no son primos relativos" << endl;
    }
}