/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file ComputeInt_main.cpp
 * @author Alvaro Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 27 2022
 * @brief Desarrollo de la clase ComputeInt
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos
 */
#include "ComputeInt.h"

int main() {
  ComputeInt computation;
  computation.Factorial(5);
  computation.SumSerie(100);
  if (computation.IsPrime(13)) {
    cout << "13 es primo" << endl;
  }
  else {
    cout << "13 no es primo" << endl;
  }
  computation.IsPerfectPrime(977);
  computation.AreRelativePrime(13, 17);
  return 0;
}