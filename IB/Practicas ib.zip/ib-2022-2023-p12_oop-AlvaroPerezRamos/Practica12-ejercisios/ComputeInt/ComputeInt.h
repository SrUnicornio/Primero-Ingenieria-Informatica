/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file ComputeInt.h
 * @author Alvaro Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 27 2022
 * @brief Desarrollo de la clase ComputeInt
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos
 */
#ifndef ComputeInt_h
#define ComputeInt_h

#include <iostream>
#include <cmath>

using namespace std;

class ComputeInt
{
public:
    ComputeInt();
    ComputeInt(int kNumero, int kNumero2);
    void Factorial(int kNumero);
    void SumSerie(int kNumero);
    bool IsPrime(int kNumero);
    void IsPerfectPrime(int kNumero);
    void AreRelativePrime(int kNumero, int kNumero2);
private:
    int kNumero;
    int kNumero2;
};

#endif 