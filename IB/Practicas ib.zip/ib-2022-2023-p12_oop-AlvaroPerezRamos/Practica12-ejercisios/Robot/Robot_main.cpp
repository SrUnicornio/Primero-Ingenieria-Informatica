/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 * 
 * @file Robot_main.cpp
 * @author Alvaro Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 27 2022
 * @brief Desarrollo de la clase Robot_main
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos
*/

#include "Robot.h"

int main(int argc, char *argv[]) {
const std::pair<int, int> kPosition{0, 0};
const Bearing kBearing {Bearing::NORTH};
Robot robot{kPosition, kBearing};
std::string sequence;
getline(std::cin, sequence);
for (const auto& movement : sequence) {
  switch (movement) {
    case 'R': robot.turn_right(); break;
    case 'L': robot.turn_left();  break;
    case 'A': robot.advance();    break;
    default: throw "Invalid command: "+std::string(1,movement);
  }
}
std::pair<int, int> final_position = robot.get_position();
std::cout << "(" << final_position.first << ", " << final_position.second  << ")" << std::endl;
return 0;
}