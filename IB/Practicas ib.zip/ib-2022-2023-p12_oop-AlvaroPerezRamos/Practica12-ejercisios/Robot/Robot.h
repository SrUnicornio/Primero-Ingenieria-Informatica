/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 * 
 * @file Robot.h
 * @author Alvaro Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 27 2022
 * @brief Desarrollo de la clase Robot
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos
*/
#ifndef Robot_h
#define Robot_h

#include <iostream>
#include <vector>
#include <string>

enum class Bearing {NORTH, EAST, SOUTH, WEST };
typedef std::pair<int,int> Coordenadas;
class Robot {
  public:
    // constructores
    Robot() = default;
    Robot(Coordenadas p, Bearing b) : position_(p), bearing_(b) {}
    // accessors
    Bearing get_bearing() const;
    Coordenadas get_position() const;
    // movements
    void turn_right();
    void turn_left();
    void advance();
    void execute_sequence(const std::string&);
  private:
    Coordenadas position_ = {0,0};
    Bearing bearing_ = Bearing::NORTH;
};
#endif