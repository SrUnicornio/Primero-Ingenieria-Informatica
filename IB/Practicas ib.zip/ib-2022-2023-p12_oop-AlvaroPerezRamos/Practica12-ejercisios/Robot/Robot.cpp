/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file Robot.cpp 
 * @author Alvaro Perez Ramos alu0101574042@ull.edu.es
 * @date Dic 27 2022
 * @brief Desarrollo de la clase Robot
 * @see https://github.com/IB-2022-2023/ib-2022-2023-p12_oop-AlvaroPerezRamos

*/
#include "Robot.h"

/**
* @brief Esta función devuelve la posición del robot.
* @param[in] position_: Posición del robot.
* @return Devuelve la posición del robot.
*/
Bearing Robot::get_bearing() const { return bearing_; }

/**
* @brief Esta función devuelve la dirección en la que se encuentra el robot.
* @param[in] bearing_: Dirección en la que se encuentra el robot.
* @return Devuelve la dirección en la que se encuentra el robot.
*/
Coordenadas Robot::get_position() const { return position_;}

/**
* @brief Esta función gira el robot a la derecha.
* @param[in] bearing_: Dirección en la que se encuentra el robot.
* @return No devuelve nada.
*/
void Robot::turn_right() {
  switch(bearing_) {
    case Bearing::NORTH: bearing_ = Bearing::EAST;  break;
    case Bearing::EAST:  bearing_ = Bearing::SOUTH; break;
    case Bearing::SOUTH: bearing_ = Bearing::WEST;  break;
    case Bearing::WEST:  bearing_ = Bearing::NORTH; break;
  }
}

/**
* @brief Esta función gira el robot a la izquierda.
* @param[in] bearing_: Dirección en la que se encuentra el robot.
* @return No devuelve nada.
*/
void Robot::turn_left()
{
  switch(bearing_) { 
    case Bearing::NORTH: bearing_ = Bearing::WEST;  break;
    case Bearing::EAST:  bearing_ = Bearing::NORTH; break;
    case Bearing::SOUTH: bearing_ = Bearing::EAST;  break;
    case Bearing::WEST:  bearing_ = Bearing::SOUTH; break;
  }
}

/**
* @brief Esta función mueve al robot una posición hacia adelante.
* @param[in] bearing_: Dirección en la que se encuentra el robot.
* @param[in] position_: Posición del robot.
* @return No devuelve nada.
*/
void Robot::advance()
{
  int& x = position_.first;
  int& y = position_.second;
  switch(bearing_) {
    case Bearing::NORTH: ++y; break;
    case Bearing::EAST:  ++x; break;
    case Bearing::SOUTH: --y; break;
    case Bearing::WEST:  --x; break;
  }
}

/**
* @brief Esta función ejecuta una secuencia de comandos.
* @param[in] commands: Secuencia de
* @return No devuelve nada.
*/
void Robot::execute_sequence(const std::string& commands)
{
  for (auto command : commands) {
    switch (command) {
      case 'R': turn_right(); break;
      case 'L': turn_left();  break;
      case 'A': advance();    break;
      default: throw "Invalid command: " + std::string(1,command);
    }
  }
}