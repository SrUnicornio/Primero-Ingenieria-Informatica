/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F de Sande
 * @date Jan, 4 2022
 * @brief Robot Simulator
 * @See https://exercism.org/tracks/cpp/exercises/robot-simulator
 */

#include <iostream>
#include "robot_simulator.h"

namespace robot_simulator {

}  // namespace robot_simulator
