# Reverse String

Welcome to Reverse String on Exercism's C++ Track.
If you need help running the tests or submitting your code, check out `HELP.md`.

## Instructions

Reverse a string

For example:
input: "cool"
output: "looc"

## Source

### Created by

- @nidhi98gupta

### Contributed to by

- @elyashiv
- @KevinWMatthews
- @patricksjackson

### Based on

Introductory challenge to reverse an input string - https://medium.freecodecamp.org/how-to-reverse-a-string-in-javascript-in-3-different-ways-75e4763c68cb