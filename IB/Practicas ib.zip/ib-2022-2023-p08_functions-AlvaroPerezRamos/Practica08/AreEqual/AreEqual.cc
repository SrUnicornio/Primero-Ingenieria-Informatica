/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Álvaro Pérez Ramos
 * @date Nov 15 2022
 * @brief Desarrolle a continuación una función cuya definición sea: bool AreEqual(const double number1, const double number2, const double epsilon = 1e-7); que devuelva true o false dependiendo de si los números que se le pasan como parámetro son aproximadamente iguales o no. El tercer parámetro, que por defecto vale 1e-7 indica un valor muy pequeño que la función tomaría como margen de error a la hora de considerar si los números son o no iguales.
 * @see https://github.com/IB-2022-2023/P08-functions/blob/main/functions.md
 *
 */
#include <cmath>
#include <iostream>
using namespace std;

bool AreEqual(const double number1, const double number2,
              const double epsilon = 1e-7) {
  if (abs(number1 - number2) < epsilon) {
    return true;
  } else {
    return false;
  }
}

int main() {
  double knumero1, knumero2;
  while (cin >> knumero1 >> knumero2) {
    cout << AreEqual(knumero1, knumero2) << "\n";
  }
}
