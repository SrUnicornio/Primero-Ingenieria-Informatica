/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 * @author Álvaro Pérez Ramos
 * @date Nov 15 2022
 * @brief  realice el cálculo de la siguiente función matemática de tres variables: g(x,y,t) = (sqr(2t-4))/(x^2 - y^2)
 * @see https://github.com/IB-2022-2023/P08-functions/blob/main/functions.md
 */
#include <iostream>
#include <cmath>
using namespace std;

double Operacion (int x, int y, int t){
    double result, r1, r2;
    r1 = (2*t)-4;
    x = pow(x,2);
    y = pow(y, 2);
    r2 = x -y;
    result = (sqrt(r1))/r2;
    return result;
}

int main() {
    double kvariable_X, kvariable_Y, kvariable_T;
    cin >> kvariable_X >> kvariable_Y >> kvariable_T;
    while (kvariable_T<2){
        cin >> kvariable_T;
        }
    cout << Operacion(kvariable_X, kvariable_Y, kvariable_T);
    return 0;
}