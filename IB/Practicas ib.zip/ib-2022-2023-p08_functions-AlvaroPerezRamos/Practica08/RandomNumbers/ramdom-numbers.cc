/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Álvaro Pérez Ramos
 * @date Nov 15 2022
 * @brief Generar un número aleatorio real r en el intervalo [n, m].
 * @see https://github.com/IB-2022-2023/P08-functions/blob/main/functions.md
 *
 */
#include <cstdlib>
#include <iostream>
using namespace std;

int aleatorio(int n, int m);
int main() {
  int knumero1, knumero2;
  cout << "Public test case \nInput\t\t\tOuput \n";
  while (cin >> knumero1 >> knumero2) {
    while (knumero1 > knumero2) {
      cin >> knumero2;
    }
    cout << aleatorio(knumero1, knumero2) << "\n";
  }
  return 0;
}

int aleatorio(int n, int m) {
  int valor = n + rand() % (m+1-n);
  return valor;
}