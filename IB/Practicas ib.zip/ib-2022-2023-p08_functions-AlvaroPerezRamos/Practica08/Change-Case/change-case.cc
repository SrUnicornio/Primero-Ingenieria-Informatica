/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Álvaro Pérez Ramos
 * @date Nov 15 2022
 * @brief tome como entrada una cadena de caracteres sin espacios e imprima como salida la misma cadena convirtiendo los caracteres que sean letras mayúsculas por minúsculas y viceversa. Los caracteres que no sean letras mayúsculas ni minúsculas deberán permanecer inalterados.
 * @see https://github.com/IB-2022-2023/P08-functions/blob/main/functions.md 
  */
#include <iostream>
using namespace std;
// Prototipo de funciones
string MayusculaMinuscula(string cadena);

int main() {
  string cadena;
  cout << "Public test cases \nInput\t\t\tOuput\n";
  while (cin >> cadena) {
    string mayuscula = MayusculaMinuscula(cadena);
    cout <<  mayuscula + "\n";
  }
  return 0;
}

string MayusculaMinuscula(string cadena) {
  for (int i = 0; i < cadena.length(); i++) {
    if (cadena[i] == toupper(cadena[i])) {
      cadena[i] = tolower(cadena[i]);
    } else if (cadena[i] == tolower(cadena[i])) {
      cadena[i] = toupper(cadena[i]);
    }
  }
  return cadena;
}
