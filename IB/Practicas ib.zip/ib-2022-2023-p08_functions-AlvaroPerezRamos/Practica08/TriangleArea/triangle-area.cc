/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Álvaro Pérez Ramos
 * @date Nov 15 2022
 * @brief Escriba un programa triangle-area.cc que tome como entrada las
 * longitudes a, b y cde los lados de un triángulo y calcule su área utilizando
 * la Fórmula de Herón. Diseñe una función cuyo nombre sea Area, que implemente
 * ese cálculo.
 * @see https://github.com/IB-2022-2023/P08-functions/blob/main/functions.md
 *
 */
#include <cmath>
#include <iostream>
using namespace std;
const double PI = atan(1) * 4;

bool EsTriangulo(const double a, const double b, const double c) {
  double alfa, beta, gamma, resultado1, resultado2;
  resultado1 = (pow(a, 2) - pow(b, 2) - pow(c, 2));
  resultado2 = resultado1 / (b * c * -2);
  alfa = acos(resultado2) * 180 / PI;

  resultado1 = (pow(b, 2) - pow(a, 2) - pow(c, 2));
  resultado2 = resultado1 / (a * c * -2);
  beta = acos(resultado2) * 180 / PI;

  resultado1 = (pow(c, 2) - pow(b, 2) - pow(a, 2));
  resultado2 = resultado1 / (b * a * -2);
  gamma = acos(resultado2) * 180 / PI;
  if (alfa + beta + gamma == 180) {
    return true;
  } else {
    return false;
  }
}

double Area(double a, double b, double c) {
  double area, s, result1;
  s = (a + b + c) / 2;
  result1 = s * (s - a) * (s - b) * (s - c);
  area = sqrt(result1);
  return area;
}
int main() {
  double klado_a, klado_b, klado_c;

  cin >> klado_a >> klado_b >> klado_c;
  if (EsTriangulo(klado_a, klado_b, klado_c) == 0) {
    cout << Area(klado_a, klado_b, klado_c);
  } else {
    cout << "Not a valid Triangle" << endl;
  }
  return 0;
}
