/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file Programa3.cc
 * @author Alvao Perez Ramos alu0101574042@ull.edu.es
 * @date Nov 25 2022
 * @brief Write a function that returns the sum of the divisors of a number n.
For instance, the sum of the divisors of 28 is 1+2+4+7+14+28 = 56.
 * @see https://jutge.org/problems/P95972
 */

#include <iostream>
using namespace std;
int sum_divisors(int x) {
  int suma{0};
  int i;
  for (i = 1; (i * i) < x; ++i) {
    if (x % i == 0) {
      suma += i;
    }
  }
  for ( ; i >=1; --i){
    if ((x%i ==0) && (x/i != i-1)){
      suma += x/i;
    }
  }
  return suma;
}

int main() {
  unsigned int numero;
  while (cin >> numero) {
    cout << sum_divisors(numero) << endl;
  }
}

