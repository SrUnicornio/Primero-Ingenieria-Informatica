/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @file Programa3.cc
 * @author Alvao Perez Ramos alu0101574042@ull.edu.es
 * @date Nov 25 2022
 * @brief 
 * @bug There are no known bugs
 * @see 
 */
#include <iostream>
using namespace std;

int largest_prime_factor(int n){
  int primo{0};
  for (int i = 2; i <= n; i++) {
    while (n % i == 0 && n != 0) {
      n /= i;
    }
   primo = i;
  }
return primo;
}

int main() {
  int numero;
  while (cin >> numero){
    cout << largest_prime_factor(numero) << endl;
  }
  return 0;
}
