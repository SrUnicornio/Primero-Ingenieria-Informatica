#include <iostream>
#include <cstdlib>
using namespace std;


void Usage(int argc, char *argv[]);
string rotate(const string line);