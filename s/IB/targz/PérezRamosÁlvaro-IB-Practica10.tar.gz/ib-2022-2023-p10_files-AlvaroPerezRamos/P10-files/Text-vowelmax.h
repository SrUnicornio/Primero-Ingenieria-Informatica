#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void Usage(int argc, char *argv[]);
void PalabraMasVocales(string kFichero);